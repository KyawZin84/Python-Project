from django.apps import AppConfig


class HrPayrollConfig(AppConfig):
    name = 'hr_payroll'
