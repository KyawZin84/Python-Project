from django.apps import AppConfig


class HrAttendanceConfig(AppConfig):
    name = 'hr_attendance'
