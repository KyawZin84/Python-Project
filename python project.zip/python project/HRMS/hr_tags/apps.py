from django.apps import AppConfig


class HrTagsConfig(AppConfig):
    name = 'hr_tags'
