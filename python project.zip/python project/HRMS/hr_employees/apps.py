from django.apps import AppConfig


class HrEmployeesConfig(AppConfig):
    name = 'hr_employees'
