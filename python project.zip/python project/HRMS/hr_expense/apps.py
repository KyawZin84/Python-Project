from django.apps import AppConfig


class HrExpenseConfig(AppConfig):
    name = 'hr_expense'
