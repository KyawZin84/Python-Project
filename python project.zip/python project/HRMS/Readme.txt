	Welcome to Human Resource Management System

first login your account

and you see Employees

click Help Button to Know What To do

Name   		password
Admin 		superuser
createuser 	User1234
deleteuser 	User1234
updateuser	User1234
viewuser 	User1234
normaluser	User1234  

superuser
name-admin
email-admin@gmail.com
passw-superuser