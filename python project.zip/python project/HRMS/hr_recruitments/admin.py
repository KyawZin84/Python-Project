from django.contrib import admin

# Register your models here.
from .models import ResumeModel

admin.site.register(ResumeModel)